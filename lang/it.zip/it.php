<?php

define("_MODIFICAEVENTO_","Modifica evento");
define("_INSERISCIEVENTO_","Inserisci evento");
define("_SUPPLENZAEVENTO_","Pianifica supplenza");
define("_DATAEVENTO_","Data evento");
define("_ORAINIZIO_","Ora inizio");
define("_ORAFINE_","Ora fine");
define("_TIPOEVENTO_","Tipo evento");
define("_CLASSE_","Classe");
define("_NOTES_","Note");
define("_DURATA_","Durata");
define("_OPZCANCNONOTIFY_","CANCELLA SENZA NOTIFICA");
define("_OPZCANCNORECUPERO_","CANCELLA SENZA LEZIONE DI RECUPERO (<24 ore)");
define("_OPZCANCSIRECUPERO_","CANCELLA E PIANIFICA LA LEZIONE DI RECUPERO");
define("_OPZCANCSINOTIFY_","CANCELLA E NOTIFICA");
define("_LBLDATAPREVRECUPERO_","Data prevista per la lezione di recupero");
define("_BTNCONFSUPPLENZA_","Conferma supplenza");
define("_BTNSALVA_","Salva");
define("_BTNCANCELLA_","Cancella questo evento");
define("_LBLSUBSTREQUEST_","RICHIESTA SOSTITUZIONE, IN ATTESA DI CONFERMA");
define("_BTNCHIUDI_","Chiudi finestra");
define("_BTNSUPPLENZA_","Supplenza");
define("_MSGSEISICURO_","Sei sicuro dell'operazione?");
define("_LBLSENSE_","SENSE:&nbsp;");
define("_LBLOTEC_","OTEC:&nbsp;");
define("_LBLNODATA_","Nessuna data inserita");
define("_LBLLCI_","Libro Controllo classe");
define("_DOMENICA_","Domenica");
define("_LUNEDI_","Luned&igrave;");
define("_MARTEDI_","Marted&igrave;");
define("_MERCOLEDI_","Mercoled&igrave;");
define("_GIOVEDI_","Gioved&igrave;");
define("_VENERDI_","Venerd&igrave;");
define("_SABATO_","Sabato");
define("_GENNAIO_","Gennaio");
define("_FEBBRAIO_","Febbraio");
define("_MARZO_","Marzo");
define("_APRILE_","Aprile");
define("_MAGGIO_","Maggio");
define("_GIUGNO_","Giugno");
define("_LUGLIO_","Luglio");
define("_AGOSTO_","Agosto");
define("_SETTEMBRE_","Settembre");
define("_OTTOBRE_","Ottobre");
define("_NOVEMBRE_","Novembre");
define("_DICEMBRE_","Dicembre");
define("_LBLNODOCENTEASS_","Nessun docente associato");
define("_BRNCALENDARIO_","Cal");
define("_BTNCONFEVTESALVA_","CONFERMA DATE E CARICA EVENTI");
define("_NOISCRITTI_","Non iscritti");
define("_BTNISCRITTI_","Iscritti");
define("_BACKTOINS_"," Torna all'inserimento");
define("_CODLIVCORSO_","Tipologia/Livello"); //tipologia-livello del crso
define("_LBLCOLORE_","Colore");
define("_LBLDOCENTI_","Docenti");
define("_BTNRESET_","Ripristiva i valori precedenti");
define("_MSGDELSTUDCLASSE_","Concludere l'iscrizione dello studente alla classe?Premendo OK lo studente non sara' piu' iscritto alla classe dalla data ordierna; premendo Annulla verra' cancellata completamente l'iscrizione dello studente alla classe (correzione di errore)");
define("_MSGDATADELSTUDCLASSE_","Inserire la data di termine dd/mm/yyyy es. 20/06/2010");
define("_TITREPORT_","Report");
define("_REPORT1TIT_","Statistiche lavoro docente");
define("_PERIODO_","Periodo");
define("_BTNELABORA_","Elabora");
define("_EMAIL_","Email");
define("_LBLGRANTBOSS_","Autorizzazione livello BOSS");
define("_LBLGRANTVICEBOSS_","Autorizzazione livello VICEBOSS");
define("_LBLGRANTUSER_","Autorizzazione livello UTENTE NORMALE");
define("_NOASSOCIAZIONE_","Nessuna associazione");
define("_TXTDISABILITA_","Disattiva");
define("_TXTABILITA_","Attiva");
define("_LBLUSERNAME_","Username");
define("_LBLPASSWORD_","Password");
define("_LBLNOME_","Nome");
define("_LBLEMAIL_","Email");
define("_OPZUTENTENORMALE_","Utente normale");
define("_OPZVICEBOSS_","ViceAdmin");
define("_OPZBOSS_","Boss");
define("_MSGDBQUERYKOSAVE_","Non &egrave; stato possibile memorizzare i dati: riprovare pi tardi.");
define("_MSGDBQUERYOKSAVE_","Modifiche salvate correttamente");
define("_TITDBQUERY_","Salvataggio dati");
define("_BTNDBQUERYBACK_","Indietro");
define("_BTNDBQUERYGO_","Prosegui");
define("_LBLAZIONE_","Azione");
define("_LBLINIZIO_","Inizio:");
define("_LBLFINE_","Fine:");
define("_TITINCONFLITTOCON_","in conflitto con");
define("_BTNELABCONFL_","Elabora e Verifica");
define("_MSGBACKWEEK_","Settimana precedente");
define("_MSGNEXTWEEK_","Settimana successiva");
define("_MSGREFRESH_","Aggiorna");
define("_TITALERTBOX_","AlertBox");
define("_MSGMBOXNOMSG_","No message");
define("_LBLCONFSOST_","<BR>Sostituzione da confermare"); //msg stampato sotto l'evento da confermare
define("_LBLSOSTNOCONF_","<BR>Sost. non confermata"); //msg stampato sotto l'evento da confermare
define("_LBLSOSTREQ_","<BR>Richiesta sost."); //msg stampato sotto l'evento da confermare
define("_LBLSOSTCONF_","<BR>Sostituzione confermata"); //msg stampato sotto l'evento da confermare
define("_MSGMBOXUPDATE_","MessageBox updated!");
define("_TITMBOXEDIT_","Edit messagebox");
define("_BTNMBOXUPDATE_","UPDATE");
define("_BTNMBOXCHIUDI_","CLOSE");
define("_OK_","OK");
define("_ALERT_","ALERT");
define("_ABOXTITSOSTREQ_","RICHIESTA SOSTITUZIONE");
define("_ABOXMSGSOSTREQ_","Non e' stata programmata nessuna sostituzione per il seguente evento:");
define("_CORSO_","Corso");
define("_BTNPLANSOST_","pianifica sostituzione"); //pulsante
define("_ABOXTITCONFSOST_","CONFERMA SOSTITUZIONE");
define("_ABOXMSGCONFSOST_","Confermare la disponibilita' ad effettuare la seguente sostituzione:");
define("_LBLDOCSOSTITUIRE_","Docente da sostituire");
define("_ABOXMSGCLICKCONFIRM_","Click to confirm");

define("_LBLMBARUSER_","User:"); //BARRA MENU
define("_LBLMBARLOGOUT_","Log Out"); //BARRA MENU
define("_LBLMBARTIMETAB_","TimeTable"); //BARRA MENU
define("_LBLMBARCLIENTI_","Clienti"); //BARRA MENU
define("_LBLMBARSTUDENTI_","Studenti"); //BARRA MENU
define("_LBLMBARCLASSI_","Classi"); //BARRA MENU
define("_LBLMBARDOCENTI_","Docenti"); //BARRA MENU
define("_LBLMBARREPORT_","Report"); //BARRA MENU
define("_LBLMBARUSERS_","Users"); //BARRA MENU

define("_LBLMBARLINGUA_","Language"); //BARRA MENU



define("_LBLTEL_","Tel:");
define("_LBLMOBILE_","Mobile:");
define("_LBLFAX_","Fax:");
define("_LBLRUT_","Rut");
define("_LBLGIRO_","Giro");
define("_LBLNUM_","Num");
define("_LBLCOMUNE_","Comune");
define("_LBLEMAIL1_","Email1");
define("_LBLEMAIL2_","Email2");
define("_LBLAZIENDA_","Azienda/Cliente");
define("_MSGNOUSER_","Nessun utente"); //option nella finestra di selezione degli utenti
define("_BTNRICERCA_","Filtra");
define("_TITCLIENTE_","Cliente");


//----------------------------------------------------------------------------------

define("_LBLVATNO_","P.IVA");
define("_LBLCONTABILI_","Dati contabili");
define("_TITDOCENTI_","Docenti");//titolo della form
define("_LBLNICK_","Nickname");
define("_LBLNOUSERASS_","Nessun utente associato");
define("_MSGUSERATTIVO_","Attivo");
define("_MSGUSERNONATTIVO_","Non attivo");
define("_MODDOCENTE_","Modifica docente");
define("_INSDOCENTE_","Inserisci docente");

//----------------------------------------------------------------------------------

define("_CLIENTE_","Cliente");
define("_INDIRIZZO_","Indirizzo");
define("_CONTATTI_","Contatti");
define("_RIFERIMENTI_","Riferimenti");
define("_EMAIL_","Email");
define("_ALTREINFO_","Altre informazioni");
define("_MODCLIENTE_","Modifica cliente");
define("_INSCLIENTE_","Inserisci cliente");



define("_STUDENTE_","Studente");
define("_APPARTAMENTO_","Appartamento");
define("_STATOATTIVO_","Stato"); //toplabel per palla verde/rossa
define("_INSSTUDENTE_","Inserisci studente");
define("_MODSTUDENTE_","Modifica studente");



define("_CLASSIINSEGNAMENTO_","Corsi di insegnamento");
define("_DESCRIZIONE_","Descrizione");
define("_LIVELLOCORSO_","Livello");
define("_CODICI_","Codici");
define("_PLANNING_","Pianificato");
define("_LUOGO_","Luogo");
define("_DATAINIZIO_","Data inizio:");
define("_DATAFINE_","Data fine:");
define("_DURATATOTALE_","Durata totale:");
define("_OREPIANIFICATE_","Ore pianificate");
define("_DURATALEZIONE_","Durata lezione");
define("_COMPENSO_","Compenso");
define("_ATTIVITA_","Attivit&agrave;");
define("_INSCLASSEINSEGNAMENTO_","Inserisci nuova classe");
define("_MODCLASSEINSEGNAMENTO_","Modifica classe selezionata");





define("_LBLPREFDAY_","Modifica la pianificazione settimanale");
define("_LBLMATITA_","Modifica questa riga");
define("_LBLCANCELLA_","Elimina questa riga");
define("_TITOLOPREFDAY_","Pianifica corso");
define("_DATECALCOLATE_","Date calcolate"); //tabella prefday che mostra le date elaborate dal sistema
define("_LEZIONENN_","Lezione n. ");


define("_NOCHANGE_","NO CHANGE");
define("_NOINS_","NON INSERIRE");
define("_SOST_","SOSTITUZIONE");
define("_DELSAMED_","ELIMINA SENZA NOTIFICA");
define("_DELNOTIF_","ELIMINA CON NOTIFICA");

define("_TITCONFLITTO_","ANALISI CONFLITTI");


define("_USERNAME_","Gestione utenti");


define("_LBLPERMESSI_","Permessi");
define("_LBLDATACREAZIONE_","Data creazione");
define("_LBLASSOCIATO_","Profilo associato");
define("_LBLSTATO_","Stato");
define("_DOCENTE_","Docente");
define("_TITSTUDENTE_","Studente");
define("_MODUSER_","Modifica user");
define("_INSUSER_","Inserisci nuovo user");

define("_SOSTCONF_","Sostituzione confermata");
define("_EVTSOSTITUITO_","Evento sostitutivo confermato");
define("_SOSTDAPROG_","Sostituzione in attesa di definizione");
define("_SOSTPROGDACONF_","In attesa della conferma della sostituzione");
define("_SOSTDACONF_","Sostituzione in attesa di conferma");





$vetconvlang=array();

//TIPOEVENTO
$vetconvlang['_LEZIONE_']="Lezione";
$vetconvlang['_TESTDIAGNOSTICO_']="Test diagnostico";
$vetconvlang['_MEETINGPROF_']="Meeting professori";
$vetconvlang['_COLLOQUIOPROF_']="Colloquio professore";
$vetconvlang['_INITIALMEETING_']="Initial meeting";
$vetconvlang['_OFFICEWORK_']="Office work";
$vetconvlang['_NOTAVAILABLE_']="Not available";


?>
