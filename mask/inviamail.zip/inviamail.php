<?php
  $pagever = "1.0";
  $pagemod = "12/07/2010 21.56.52";
  define("APP_DEBUG",0);
  
  require_once ("form_cfg.php");
  require "../phpmailer/class.phpmailer.php";
  
  $backurl = urldecode($_REQUEST['backurl']);
  $tipoact = $_REQUEST['tipoact'];
  
  //myprint_r($_REQUEST);
  
  switch ($tipoact) {
    case "1":
            $notify=1;
            break;
    case "2":
            $notify=2;
            break;
  }
  
  $admaddr[1]['nome'] = "Michele";
  $admaddr[1]['addr'] = "michele.mentucci@gmail.com";
  $admaddr[2]['nome'] = "Gionata admin";
  $admaddr[2]['addr'] = "partireper@gmail.com";
  
  
  $query = "SELECT * FROM tipo";
  $result = mysql_query ($query) or die ("Error2.1");
  while ($line = mysql_fetch_assoc($result)) {
    $tipo[$line['id']]['descr']=$line['descr'];
  }
  mysql_free_result($result);
  
  $query = "SELECT appuntamento.id as appuntamento_id, appuntamento.idpstudi as idpstudi, appuntamento.iddocente as iddocente,
    appuntamento.dtini as dtini, appuntamento.dtfine as dtfine, appuntamento.tipo as tipo, appuntamento.note as note, 
    appuntamento.idsostituzione as idsostituzione, appuntamento.fsost as fsost, appuntamento.fnotify as fnotify,
    docente.nome as docente_nome, docente.email as docente_email, pstudi.descr as pstudi_descr, corso.codlivello as codlivello
    FROM appuntamento LEFT JOIN docente ON appuntamento.iddocente=docente.id AND docente.trashed<>1
    LEFT JOIN pstudi ON appuntamento.idpstudi=pstudi.id AND pstudi.trashed<>1
    LEFT JOIN corso ON pstudi.idcorso=corso.id
    WHERE appuntamento.trashed<>1 AND fnotify=".$notify;
  $result = mysql_query ($query) or die ("Error_1.1");
  
  while ($line = mysql_fetch_assoc($result)) {
    $chiave = $line['appuntamento_id'];
    
    $evt[$chiave]['idpstudi'] = $line['idpstudi'];
    $evt[$chiave]['iddocente'] = $line['iddocente'];
    $evt[$chiave]['dtini'] = $line['dtini'];
    $evt[$chiave]['dtfine'] = $line['dtfine'];
    $evt[$chiave]['tipo'] = $line['tipo'];
    $evt[$chiave]['note'] = $line['note'];
    $evt[$chiave]['idsostituzione'] = $line['idsostituzione'];
    $evt[$chiave]['fsost'] = $line['fsost'];
    $evt[$chiave]['fnotify'] = $line['fnotify'];
    $evt[$chiave]['docente_nome'] = $line['docente_nome'];
    $evt[$chiave]['docente_email'] = $line['docente_email'];
    $evt[$chiave]['pstudi_descr'] = $line['pstudi_descr'];
    $evt[$chiave]['codlivello'] = $line['codlivello'];
    
    if ($line['idsostituzione']!="") {$evt[$line['idsostituzione']]['idsostda']=$chiave;}
    
    $idpstudi .= $line['idpstudi'].", ";
    
  }
  //myprint_r($evt);
  
  //testomail
  $numemail=0;
  foreach ($evt as $key=>$cur) {
    $messaggio = new PHPmailer();
    $messaggio->From='eteam@sec-community.it';
    $messaggio->FromName='GESTIONE TTO';
    
    
    

    $txt="";
    $toadmin=0;
    //messaggi
    if ($cur['fsost']==1) {
      //il presente evento � stato sostituito
      $txt = "MESSAGGIO RICEVUTO DAL PROFESSORE NON DISPONIBILE - RICEVUTA DI CONFERMA DELL'ACCETTAZIONE DELLA SOSTITUZIONE<BR>Sostituzione confermata:<BR>
      Tipo evento:".$tipo[$cur['tipo']]['descr']."<BR>
      Data evento:".date("d/m/Y",$cur['dtini'])."<BR>
      Ora inizio:".date("H:i",$cur['dtini'])."<BR>
      Ora fine:".date("H:i",$cur['dtfine'])."<BR>
      Classe:".$cur['pstudi_descr']."<BR>
      Corso:".$cur['codlivello']."<BR>
      <BR>
      Docente supplente:".$evt[$cur['idsostda']]['docente_nome'];
      $subject = "Sostituzione confermata";
      
      //to docente, admin
      $toadmin=1;
      $noagain=1;
      $messaggio->AddAddress('michele.mentucci@gmail.com');
      $txt.= "<BR>EMAIL TO:".$cur['docente_email'];
    }
    if ($cur['fsost']==0 && $cur['idsostituzione']!="") {
      //sostituzione confermata
      $txt = "MESSAGGIO RICEVUTO DAL DOCENTE - RICEVUTA DI CONFERMA DELL'ACCETTAZIONE DELLA SOSTITUZIONE<BR>Confermata la seguente sostituzione:<BR>
      Tipo evento:".$tipo[$cur['tipo']]['descr']."<BR>
      Data evento:".date("d/m/Y",$cur['dtini'])."<BR>
      Ora inizio:".date("H:i",$cur['dtini'])."<BR>
      Ora fine:".date("H:i",$cur['dtfine'])."<BR>
      Classe:".$cur['pstudi_descr']."<BR>
      Corso:".$cur['codlivello']."<BR>
      <BR>
      Docente da sostituire:".$evt[$cur['idsostituzione']]['docente_nome'];
      $subject = "Ricevuta conferma sostituzione";
      
      //to docente, admin
      $toadmin=1;
      $noagain=1;
      $messaggio->AddAddress('michele.mentucci@gmail.com');
      $txt.= "<BR>EMAIL TO:".$cur['docente_email'];
    }
    
    if ($cur['fsost']==-1) {
      //evt in attesa di essere sostituito
      $txt = "MESSAGGIO RICEVUTO DALL'ADMIN CHE SEGNALA LA PRESENZA DI EVENTI DI CUI DEVE ESSERE PROGRAMMATA LA SOSTITUZIONE<BR>Non e' stata programmata nessuna sostituzione per il seguente evento:<BR>
      Tipo evento:".$tipo[$cur['tipo']]['descr']."<BR>
      Data evento:".date("d/m/Y",$cur['dtini'])."<BR>
      Ora inizio:".date("H:i",$cur['dtini'])."<BR>
      Ora fine:".date("H:i",$cur['dtfine'])."<BR>
      Classe:".$cur['pstudi_descr']."<BR>
      Corso:".$cur['codlivello'];
      $subject = "Evento in attesa di sostituzione";
      
      //admin
      $toadmin=1;
    }
    
    if ($cur['fsost']==-2) {
      //evt in attesa di conferma
      $txt = "MESSAGGIO RICEVUTO DAL PROFESSORE NON DISPONIBILE CHE SEGNALA CHE LA SOSTITUZIONE E' STATA PROGRAMMATA MA ANCORA NON CONFERMATA<BR>Sostituzione programmata, in attesa di ricevere conferma.<BR>Evento sostituito:<BR>
      Tipo evento:".$tipo[$cur['tipo']]['descr']."<BR>
      Data evento:".date("d/m/Y",$cur['dtini'])."<BR>
      Ora inizio:".date("H:i",$cur['dtini'])."<BR>
      Ora fine:".date("H:i",$cur['dtfine'])."<BR>
      Classe:".$cur['pstudi_descr']."<BR>
      Corso:".$cur['codlivello']."<BR>
      <BR>
      Docente supplente:".$evt[$cur['idsostda']]['docente_nome'];
      $subject = "Sostituzione programmata, attesa per conferma";
      
      //to docente, admin
      $toadmin=1;
      $messaggio->AddAddress('michele.mentucci@gmail.com');
      $txt.= "<BR>EMAIL TO:".$cur['docente_email'];
    }
    if ($cur['fsost']==-3) {
      //evt in attesa di conferma
      $txt = "MESSAGGIO RICEVUTO DAL DOCENTE CHE DOVRA' SOSTITUIRE IL PROFESSORE NON DISPONIBILE<BR>Confermare la disponibilita' ad effettuare la seguente sostituzione:<BR>
      Tipo evento:".$tipo[$cur['tipo']]['descr']."<BR>
      Data evento:".date("d/m/Y",$cur['dtini'])."<BR>
      Ora inizio:".date("H:i",$cur['dtini'])."<BR>
      Ora fine:".date("H:i",$cur['dtfine'])."<BR>
      Classe:".$cur['pstudi_descr']."<BR>
      Corso:".$cur['codlivello']."<BR>
      <BR>
      Docente da sostituire:".$evt[$cur['idsostituzione']]['docente_nome']."<BR>
      <BR>
      Si prega di confermare quanto prima, cliccando sul link riportato <A HREF='http://timetable.ilmastino.net'>LINK</A>";
      $subject = "Sostituzione in attesa di conferma";
      
      //to docente, admin
      $toadmin=1;
      $messaggio->AddAddress('michele.mentucci@gmail.com');
      $txt.= "<BR>EMAIL TO:".$cur['docente_email'];
    }
    
    if ($toadmin==1) {
      foreach ($admaddr as $keyaddr=>$curaddr) {
        $messaggio->AddAddress($curaddr['addr']);
      }
    }
    
    $messaggio->MsgHTML($txt);
    $messaggio->Subject=$subject;
    
    if(!$messaggio->Send()){ 
      //echo $messaggio->ErrorInfo; 
    }else{ 
      //echo "- Email inviata correttamente!<BR>";
    }
    
    /*$numemail++;
    $msgemail[$numemail]['to'] = "?";
    $msgemail[$numemail]['txt'] = $txt;*/
    unset ($messaggio);
    if ($noagain==1) {
      $updquery[] = "UPDATE appuntamento SET fnotify=0 WHERE id=".$key;
    } else {
      $updquery[] = "UPDATE appuntamento SET fnotify=2 WHERE id=".$key;
    }
    
  }
  //myprint_r($updquery);
  foreach ($updquery as $keyquery => $curquery) {
    mysql_query($curquery) or die ("Error3.1");
  }
?>
<HTML>
<head>
  <title>...</title>
  <meta http-equiv="refresh" content="1;url=<?=$backurl?>">
</head>
<body></body>
</HTML>